print(1)
